#include <stdio.h>
#include <vector>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <fstream>
#include <iostream>

using namespace std;

/* The almighty MAIN */
int main(int argc, char* argv[]){

  
  // Create the robot objects.
  ifstream inputFile;
  inputFile.open("./inputFile", std::fstream::in);
  string chromo;
  inputFile >> chromo;
  inputFile.close();

  string answer = "00000000000000000000000000000000";
  float fitness = 0.;

  for(unsigned int i = 0; i < chromo.size(); i++){
    if(chromo[i] == answer[i]) fitness += 1.;
  }
  

  ofstream outputFile;
  outputFile.open("./outputData", std::fstream::trunc);
  outputFile << chromo <<"\t" << fitness<<"\n"; 
  outputFile.close();
   
  return 0;
}
