#include <iostream>
#include <stdio.h>
#include <vector>
#include <string>
#include <iostream>
#include <sstream> 
#include <fstream> 
#include <math.h>
#include <time.h>  

#include "Population.h"
#include "Controller.h"

using namespace std;

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

void LoadPopulation(Population * p, int nControllers);
void SavePopulation(Population * p, int nControllers);
void RankPopulation(Population * p);
float CalculateDiversity(Population * p);
Controller * WeightedSelect(Population * p);
Controller * TournamentSelect(Population * p);
Controller * OnePointCrossOver(Controller* a, Controller* b);
Controller * TwoPointCrossOver(Controller* a, Controller* b);
Controller * Mutate(Controller * a);
float GetRandom();

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

int main(int argc, char* argv[]){

  srand (time(NULL));

  int populationSize = atoi(argv[1]);
  float mutationRate = 0.05;

  Population * popn = new Population(); 
  
  // Load the evaluated controllers into the population
  LoadPopulation(popn, populationSize);

  popn->Rank();
  float diversity =  CalculateDiversity(popn);
  
  /*if(diversity > 0.5) mutationRate = 0.05;
  else if(diversity < 0.4) mutationRate = 0.1;
  else if(diversity < 0.3) mutationRate = 0.15;
  else if(diversity < 0.2) mutationRate = 0.2;
  else mutationRate = 0.25;*/

  cout << "Diversity = " << diversity <<"\n";
  cout << "RANKED POPULATION\n=====================\n";
  for(int i = 0; i < populationSize; i++){
    Controller * c = popn->GetController(i);
    cout << c->GetChromo() << "\t" << c->GetFitness() << "\t\t" 
	 << c->GetDistRank() <<"("<<c->GetDist()<<")" << "\t"
	 << c->GetStdXRank() <<"("<<c->GetStdX()<<")" <<"\t"
	 << c->GetNCollideRank() <<"("<<c->GetNCollide()<<")" <<"\n";
  }
  cout << "\n=====================\n";
  //getchar();

  // Create a new population based on the old one.
  // Use elitism, and roulette selection.
  Population *newPopn = new Population();
  //newPopn->AddController(popn->GetFittest()); // Elitism.

  for(int d = 0; d < populationSize; d++){
    // Selection (Roulette).
    //Controller * a = WeightedSelect(popn);
    //Controller * b = WeightedSelect(popn);
    
    // Selection (Tournament k = 2).
    Controller * a = TournamentSelect(popn);
    Controller * b = a;
    while(a==b) 
      b = TournamentSelect(popn);

 
    // Crossover.
    //Controller * c = OnePointCrossOver(a,b);
    Controller * c = TwoPointCrossOver(a,b);

    // Mutation.
    if(GetRandom() <= mutationRate){
	c = Mutate(c);
    }    

    newPopn->AddController(c);
    
  }

  // Save the new population.
  SavePopulation(newPopn, populationSize);
  //getchar();
  return 0;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

float CalculateDiversity(Population * p){
  float diversity = 0.;

  // Create an array of strings that will store the chromos 
  int nControllers = p->GetNumberOfControllers();
  string * chromoArray = new string[nControllers];
 
  for(int i = 0; i < nControllers; i++){
    chromoArray[i] = p->GetController(i)->GetChromo();
  }  

  int chromoLength = chromoArray[0].size();

  for(int i = 0; i < chromoLength; i++){
    // Reset count array
    float letterCounter[5] = { 0., 0., 0., 0., 0. }; 
        
    for(int d = 0; d < nControllers; d++){
      char position_i = chromoArray[d][i];
      if(position_i == 'N') letterCounter[0] += 1.;
      if(position_i == 'E') letterCounter[1] += 1.;
      if(position_i == 'W') letterCounter[2] += 1.;
      if(position_i == 'S') letterCounter[3] += 1.;
      if(position_i == '0') letterCounter[4] += 1.;
    }
    
    for(int i =0; i < 5; i++){
      float val = letterCounter[i];
      if(val > 0.)
	diversity += val*log10(val);
    }
  
  }
  
  float minDiversityMeasure = (float)chromoLength*nControllers*log10(nControllers);

  return 1. - diversity / minDiversityMeasure;
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

void LoadPopulation(Population * p, int nControllers){
  ifstream initFile;
 
  // Open all the files in "tested" directory  
  for(int i = 0; i < nControllers; i++){
    std::stringstream ss;
    ss << "./tested/individual"<< i+1 <<".dat";
  
    initFile.open (ss.str().c_str());

    string chrome;
    float fitness, dist, stdX, stdY, nCollide;
    
    initFile >> chrome;
    initFile >> fitness;
    initFile >> dist;
    initFile >> stdX;
    initFile >> stdY;
    initFile >> nCollide;

    p->AddController(new Controller(chrome, fitness, dist, stdX, stdY, nCollide));
    
    initFile.close();   
  }

  /*cout << "INITIAL POPULATION\n=====================\n";
  for(int i = 0; i < nControllers; i++){
    Controller * c = p->GetController(i);
    cout << c->GetChromo() << "\t" << c->GetFitness() << "\n";
  }/
  cout << "\n=====================\n";*/

}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

void SavePopulation(Population * p, int nControllers){
  ofstream outputFile;
  //cout << "FINAL POPULATION\n=====================\n";
  
  for(int i = 0; i < nControllers; i++){
    std::stringstream ss;
    ss << "./untested/individual"<< i+1 <<".dat";
    outputFile.open(ss.str().c_str(), std::fstream::trunc);
        
    Controller * c = p->GetController(i);
    outputFile << c->GetChromo() <<" 0. 0. 0. 0. 0.";
    //cout << c->GetChromo() << "\t" << c->GetFitness() << "\n";
    outputFile.close();   
  }

  //cout << "\n=====================\n";

};

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Controller * TournamentSelect(Population * p){

  int nControllers = p->GetNumberOfControllers();

  int index1 = (int)nControllers*GetRandom();
  int index2 = index1;
  
  while(index2 == index1)
    index2 = (int)nControllers*GetRandom();

  Controller* a = p->GetController(index1);
  Controller* b = p->GetController(index2);

  //printf("Tourn. Sel. %d\t%d\n", index1, index2);

  if(a->GetFitness() > b->GetFitness()){
    //printf("%d\n", index1);
    return a;
  }
  else{ 
    //printf("%d\n", index2);
    return b;  
  }
}
//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Controller * WeightedSelect(Population * p){
  
 Controller * c;
 int nControllers = p->GetNumberOfControllers();
 float wheel[nControllers];

 // Normalize Weight
 float W = 0.;
 for(int i = 0; i < nControllers; i++)
   W += (p->GetController(i))->GetFitness();
 for(int i = 0; i < nControllers; i++){
   wheel[i] = p->GetController(i)->GetFitness()/W;
 }

 // Build the wheel
 for(int i = 0; i < nControllers; i++){
   if(i == 0) wheel[i] = wheel[i];
   else wheel[i] = wheel[i-1]+wheel[i];
  
 }

 // Roulette Sampling 
 float value = GetRandom();
 
 for(int i = 0; i < nControllers; i++){
   if( value <= wheel[i]){ 
     c = new Controller(p->GetController(i));
     break;
   } 
 }
 return c;

};

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
// 1 point cross over. 
Controller * OnePointCrossOver(Controller* a, Controller* b){
  string chromoA = a->GetChromo();
  string chromoB = b->GetChromo();
  string newChromo;

  int length = chromoA.size();
  int index1 = (int)length*GetRandom();
  
  // Append chromoA to newChromo up to index1
  for(int i = 0; i < index1; i++){
    newChromo += chromoA[i];
  }

  for(int i = index1; i < length; i++){
    newChromo += chromoB[i];
  }
  
  return new Controller(newChromo, 0., 0., 0. ,0.,0.);
};

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Controller * Mutate(Controller * a){
  string oldChromo = a->GetChromo();
  int length = oldChromo.size();
  
  string newChromo;
  string alphabet("NESW0");

  int geneIndex = (int)length*GetRandom();
  
  int alphabetIndex = (int)5*GetRandom();
  
  for(int i = 0; i < length; i++){
    if(i == geneIndex){
      if(i==16)
	newChromo += "0";
      else
	newChromo += alphabet[alphabetIndex];
    }
    else
      newChromo += oldChromo[i];
  }
 
  return new Controller(newChromo, 0., 0., 0. ,0.,0.);
};

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Controller * TwoPointCrossOver(Controller* a, Controller* b){
  string chromoA = a->GetChromo();
  string chromoB = b->GetChromo();
  string newChromo;

  int length = chromoA.size();
  int index1 = (int)length*GetRandom();
  int index2 = index1;
  while(index1 == index2)
    index2 = (int)length*GetRandom();

  if(index2 < index1){
    int temp = index2;
    index2 = index1;
    index1 = temp;
  }
  
  // Append chromoA to newChromo up to index1
  for(int i = 0; i < chromoA.size(); i++){
    if(i < index1) newChromo += chromoA[i];
    else if(i < index2) newChromo += chromoB[i];
    else newChromo += chromoA[i];
  }

  //printf("%d\t%d\n", index1, index2);
  //printf("%s\n%s\n", chromoA.c_str(), chromoB.c_str());
  //printf("---------------------------------\n");
  //printf("%s\n", newChromo.c_str());
    
  return new Controller(newChromo, 0.,0.,0.,0.,0.);
}

//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

float GetRandom(){
  return (float)rand()/RAND_MAX;
};
